#!/bin/bash
set -e

echo "[+] Running Terraform..."
cd ../terraform
terraform init
terraform apply -auto-approve

echo "[+] Extracting IP address..."
IP=$(terraform output -raw instance_ip)

echo "[+] Running Ansible..."
cd ../ansible
ANSIBLE_HOST_KEY_CHECKING=False ansible-playbook -i "$IP," install_nifi.yml
ANSIBLE_HOST_KEY_CHECKING=False ansible-playbook -i "$IP," install_minio.yml
ANSIBLE_HOST_KEY_CHECKING=False ansible-playbook -i "$IP," install_springboot.yml

echo "[✔] TriggerIQ deployed at $IP"