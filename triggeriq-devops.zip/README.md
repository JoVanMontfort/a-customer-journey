# 📘 TriggerIQ Dev Stack

## 🚀 Overview
This is a complete local-to-cloud DevOps stack for TriggerIQ, integrating Apache NiFi, PostgreSQL, MinIO, and a Spring Boot fallback API. It supports both local Docker Compose development and cloud-native Kubernetes deployment.

## 🔧 Requirements
- Docker + Docker Compose
- Java 17 SDK
- Kubernetes (e.g. Minikube, GKE, EKS)
- GitHub Actions configured with `DOCKER_USERNAME`, `DOCKER_PASSWORD`, and `KUBECONFIG` secrets

## 🛠 Local Development
```bash
docker-compose up --build
```

- NiFi:        http://localhost:8080
- MinIO:       http://localhost:9001 (user: minioadmin)
- PostgreSQL:  localhost:5432 (user: triggeriq)
- Fallback API: http://localhost:8081

## ☸️ Kubernetes Deployment
```bash
docker build -t yourregistry/fallback-api:latest ./fallback-service
docker push yourregistry/fallback-api:latest
kubectl apply -f kubernetes/deployment.yaml
kubectl apply -f kubernetes/service.yaml
```

## ⚙️ CI/CD with GitHub Actions
The workflow at `.github/workflows/deploy.yaml` handles Docker build and K8s deployment.

Secrets required:
- `DOCKER_USERNAME`
- `DOCKER_PASSWORD`
- `KUBECONFIG`

---
Happy shipping TriggerIQ 🚀
